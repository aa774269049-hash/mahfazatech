export const jobCategories = [
    { id: 1, name: 'تكنولوجيا المعلومات', description: 'وظائف في مجال البرمجة وتطوير المواقع' },
    { id: 2, name: 'التسويق', description: 'وظائف في التسويق الرقمي والتقليدي' },
    { id: 3, name: 'التعليم', description: 'وظائف في مجال التدريس والتدريب' },
    { id: 4, name: 'الصحة', description: 'وظائف في التمريض والطب' },
];