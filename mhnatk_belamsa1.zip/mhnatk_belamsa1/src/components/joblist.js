import JobCard from './JobCard';

export default function JobList({ jobCategories, openJobDetails }) {
    return (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {jobCategories.map((cat) => (
                <JobCard key={cat.id} category={cat} onClick={() => openJobDetails(cat)} />
            ))}
        </div>
    );
}