export default function DashboardPlaceholder() {
    return (
        <div className="p-4">
            <h2 className="text-xl font-bold">لوحة التحكم</h2>
            <p>مرحباً بك! سيتم إضافة المزيد من الميزات قريباً.</p>
        </div>
    );
}