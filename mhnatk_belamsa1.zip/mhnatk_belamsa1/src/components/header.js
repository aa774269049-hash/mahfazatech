export default function Header({ setPage, user, handleLogout }) {
    return (
        <header className="bg-blue-600 text-white p-4 flex justify-between">
            <h1 className="text-lg font-bold cursor-pointer" onClick={() => setPage('home')}>مهنتك بلمسة</h1>
            <nav className="space-x-4">
                {user ? (
                    <>
                        <button onClick={() => setPage('dashboard')}>لوحة التحكم</button>
                        <button onClick={handleLogout}>تسجيل الخروج</button>
                    </>
                ) : (
                    <button onClick={() => setPage('login')}>تسجيل الدخول</button>
                )}
            </nav>
        </header>
    );
}