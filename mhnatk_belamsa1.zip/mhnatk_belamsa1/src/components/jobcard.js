export default function JobCard({ category, onClick }) {
    return (
        <div className="border p-4 rounded shadow cursor-pointer hover:bg-gray-100" onClick={onClick}>
            <h3 className="text-lg font-bold">{category.name}</h3>
            <p className="text-sm text-gray-600">{category.description}</p>
        </div>
    );
}