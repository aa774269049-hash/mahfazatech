import JobList from './JobList';

export default function Home({ jobCategories, openJobDetails }) {
    return (
        <div className="p-4">
            <h2 className="text-xl font-bold mb-4">تصنيفات الوظائف</h2>
            <JobList jobCategories={jobCategories} openJobDetails={openJobDetails} />
        </div>
    );
}