import React, { useState } from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import Modal from './components/Modal';
import Home from './components/Home';
import Login from './components/Login';
import DashboardPlaceholder from './components/DashboardPlaceholder';
import { jobCategories } from './data';
import { auth, provider, signInWithPopup, signOut } from './firebase';

export default function App() {
    const [page, setPage] = useState('home');
    const [selectedJob, setSelectedJob] = useState(null);
    const [user, setUser] = useState(null);

    const handleLogin = async () => {
        const result = await signInWithPopup(auth, provider);
        setUser(result.user);
        setPage('dashboard');
    };

    const handleLogout = async () => {
        await signOut(auth);
        setUser(null);
        setPage('home');
    };

    return (
        <div className="min-h-screen flex flex-col">
            <Header setPage={setPage} user={user} handleLogout={handleLogout} />
            <main className="flex-grow p-4">
                {page === 'home' && <Home jobCategories={jobCategories} openJobDetails={setSelectedJob} />}
                {page === 'login' && <Login handleLogin={handleLogin} />}
                {page === 'dashboard' && <DashboardPlaceholder />}
            </main>
            <Footer />

            <Modal isOpen={!!selectedJob} onClose={() => setSelectedJob(null)}>
                {selectedJob && (
                    <div>
                        <h2 className="text-lg font-bold">{selectedJob.name}</h2>
                        <p>{selectedJob.description}</p>
                    </div>
                )}
            </Modal>
        </div>
    );
}